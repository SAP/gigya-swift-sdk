//
//  PushManagerProtocol.swift
//  Gigya
//
//  Created by Shmuel, Sagi on 26/11/2019.
//  Copyright © 2019 Gigya. All rights reserved.
//

import Foundation

public protocol BasePushManagerProtocol {
    var idintityKey: String { get }
}
