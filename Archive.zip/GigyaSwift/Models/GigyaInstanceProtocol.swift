//
//  GigyaInstanceProtocol.swift
//  GigyaSwift
//
//  Created by Shmuel, Sagi on 10/03/2019.
//  Copyright © 2019 Gigya. All rights reserved.
//

import Foundation

public protocol GigyaInstanceProtocol { }
