//
//  GigyaSwift.h
//  GigyaSwift
//
//  Created by Shmuel, Sagi on 25/02/2019.
//  Copyright © 2019 Gigya. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for GigyaSwift.
FOUNDATION_EXPORT double GigyaSwiftVersionNumber;

//! Project version string for GigyaSwift.
FOUNDATION_EXPORT const unsigned char GigyaSwiftVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <GigyaSwift/PublicHeader.h>


