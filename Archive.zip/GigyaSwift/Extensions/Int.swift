//
//  Int+Exteinsion.swift
//  GigyaSwift
//
//  Created by Shmuel, Sagi on 03/04/2019.
//  Copyright © 2019 Gigya. All rights reserved.
//

import Foundation

extension Int {
    internal func minToSec() -> Int {
        return (self * 60) 
    }
}
