//
//  GigyaTfa.h
//  GigyaTfa
//
//  Created by Shmuel, Sagi on 30/06/2019.
//  Copyright © 2019 Gigya. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for GigyaTfa.
FOUNDATION_EXPORT double GigyaTfaVersionNumber;

//! Project version string for GigyaTfa.
FOUNDATION_EXPORT const unsigned char GigyaTfaVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <GigyaTfa/PublicHeader.h>


